﻿param(
    [string]$SSID = "",
    [string]$Username = "",
    [string]$Password = "",
    [string]$IsWpa3 = "0",
    [string]$Bssid = ""
)

$IsWpa3Bool = ($IsWpa3 -eq "1" -or $IsWpa3 -eq "true")

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Text;

public class WlanHelper {
    [DllImport("wlanapi.dll", SetLastError = true)]
    public static extern uint WlanOpenHandle(uint dwClientVersion, IntPtr pReserved, out uint pdwNegotiatedVersion, ref IntPtr phClientHandle);

    [DllImport("wlanapi.dll", SetLastError = true)]
    public static extern uint WlanCloseHandle(IntPtr hClientHandle, IntPtr pReserved);

    [DllImport("wlanapi.dll", SetLastError = true)]
    public static extern uint WlanEnumInterfaces(IntPtr hClientHandle, IntPtr pReserved, ref IntPtr ppInterfaceList);

    [DllImport("wlanapi.dll", SetLastError = true)]
    public static extern uint WlanScan(IntPtr hClientHandle, ref Guid pInterfaceGuid, IntPtr pDot11Ssid, IntPtr pIeData, IntPtr pReserved);

    [DllImport("wlanapi.dll", SetLastError = true)]
    public static extern uint WlanSetProfileEapXmlUserData(
        IntPtr hClientHandle,
        ref Guid pInterfaceGuid,
        [MarshalAs(UnmanagedType.LPWStr)] string strProfileName,
        uint dwFlags,
        [MarshalAs(UnmanagedType.LPWStr)] string strXmlUserData,
        IntPtr pReserved
    );

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct WLAN_CONNECTION_PARAMETERS {
        public uint wlanConnectionMode;
        [MarshalAs(UnmanagedType.LPWStr)]
        public string strProfile;
        public IntPtr pDot11Ssid;
        public IntPtr pDesiredBssidList;
        public uint dot11BssType;
        public uint dwFlags;
    }

    [DllImport("wlanapi.dll", SetLastError = true)]
    public static extern uint WlanConnect(
        IntPtr hClientHandle,
        ref Guid pInterfaceGuid,
        ref WLAN_CONNECTION_PARAMETERS pConnectionParameters,
        IntPtr pReserved
    );

    [DllImport("wlanapi.dll", SetLastError = true)]
    public static extern void WlanFreeMemory(IntPtr pMemory);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct WLAN_INTERFACE_INFO {
        public Guid interfaceGuid;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string strInterfaceDescription;
        public uint isState;
    }

    public static string SetUserDataAndConnect(string profileName, string username, string password, string bssidParam) {
        StringBuilder log = new StringBuilder();
        IntPtr clientHandle = IntPtr.Zero;
        uint negotiatedVersion = 0;
        
        uint result = WlanOpenHandle(2, IntPtr.Zero, out negotiatedVersion, ref clientHandle);
        log.AppendLine("1. WlanOpenHandle: " + result);
        if (result != 0) return log.ToString();

        try {
            IntPtr ppInterfaceList = IntPtr.Zero;
            result = WlanEnumInterfaces(clientHandle, IntPtr.Zero, ref ppInterfaceList);
            log.AppendLine("2. WlanEnumInterfaces: " + result);
            if (result != 0) return log.ToString();

            try {
                uint dwNumberOfItems = (uint)Marshal.ReadInt32(ppInterfaceList, 0);
                if (dwNumberOfItems == 0) return log.ToString();

                IntPtr pItem = new IntPtr(ppInterfaceList.ToInt64() + 8);
                WLAN_INTERFACE_INFO info = (WLAN_INTERFACE_INFO)Marshal.PtrToStructure(pItem, typeof(WLAN_INTERFACE_INFO));
                Guid interfaceGuid = info.interfaceGuid;

                log.AppendLine("   Target NIC: " + info.strInterfaceDescription);

                string eapUserDataXml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
"<EapHostUserCredentials xmlns=\"http://www.microsoft.com/provisioning/EapHostUserCredentials\">" +
"  <EapMethod>" +
"    <Type xmlns=\"http://www.microsoft.com/provisioning/EapCommon\">25</Type>" +
"    <VendorId xmlns=\"http://www.microsoft.com/provisioning/EapCommon\">0</VendorId>" +
"    <VendorType xmlns=\"http://www.microsoft.com/provisioning/EapCommon\">0</VendorType>" +
"    <AuthorId xmlns=\"http://www.microsoft.com/provisioning/EapCommon\">0</AuthorId>" +
"  </EapMethod>" +
"  <Credentials>" +
"    <Eap xmlns=\"http://www.microsoft.com/provisioning/BaseEapUserPropertiesV1\">" +
"      <Type>25</Type>" +
"      <EapType xmlns=\"http://www.microsoft.com/provisioning/MsPeapUserPropertiesV1\">" +
"        <RoutingIdentity></RoutingIdentity>" +
"        <Eap xmlns=\"http://www.microsoft.com/provisioning/BaseEapUserPropertiesV1\">" +
"          <Type>26</Type>" +
"          <EapType xmlns=\"http://www.microsoft.com/provisioning/MsChapV2UserPropertiesV1\">" +
"            <Username>" + username + "</Username>" +
"            <Password>" + password + "</Password>" +
"            <LogonDomain></LogonDomain>" +
"          </EapType>" +
"        </Eap>" +
"      </EapType>" +
"    </Eap>" +
"  </Credentials>" +
"</EapHostUserCredentials>";

                // Win11 24H2 / 25H2 호환 주입 시도 (dwFlags=1 및 dwFlags=0)
                uint setRes = WlanSetProfileEapXmlUserData(clientHandle, ref interfaceGuid, profileName, 1, eapUserDataXml, IntPtr.Zero);
                if (setRes != 0) {
                    setRes = WlanSetProfileEapXmlUserData(clientHandle, ref interfaceGuid, profileName, 0, eapUserDataXml, IntPtr.Zero);
                }
                log.AppendLine("3. Credential Injection: " + setRes);

                if (setRes == 0) {
                    WlanScan(clientHandle, ref interfaceGuid, IntPtr.Zero, IntPtr.Zero, IntPtr.Zero);
                    System.Threading.Thread.Sleep(1000);
                    return "SUCCESS|" + log.ToString();
                } else {
                    return "FAIL|" + log.ToString();
                }
            } finally {
                if (ppInterfaceList != IntPtr.Zero) WlanFreeMemory(ppInterfaceList);
            }
        } finally {
            if (clientHandle != IntPtr.Zero) WlanCloseHandle(clientHandle, IntPtr.Zero);
        }
    }
}
"@

if (-not $SSID) {
    Write-Output "SSID 파라미터가 없습니다."
    exit 1
}

$res = [WlanHelper]::SetUserDataAndConnect($SSID, $Username, $Password, $Bssid)
Write-Output $res